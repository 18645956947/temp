时间信息抽取直接在windows下运行即可。

地点信息抽取实在Ubuntu下运行成功，所依赖的包pyltp在Ubuntu下配置比较容易，使用的是ltp3.4.0版本。
